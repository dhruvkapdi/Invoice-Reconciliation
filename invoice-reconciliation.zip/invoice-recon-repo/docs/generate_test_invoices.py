import random

random.seed(42)

vendors = [
    "Tata Steel Ltd", "JSW Steel", "Ultratech Cement", "Ambuja Cements", "ACC Limited",
    "Shree Cement Ltd", "JK Cement", "Dalmia Bharat", "Larsen & Toubro Equipment",
    "BharatBenz Trucks", "Voltas Elevators", "Havells Electricals", "Finolex Cables",
    "Kirloskar Pumps", "Godrej Construction Supplies", "Schindler Elevators India",
    "Siemens Electricals", "ABB Motors & Drives", "Grasim Industries", "Birla Corp",
    "Jindal Steel & Power", "Hindalco Industries", "Polycab Wires", "RR Kabel",
    "Supreme Industries Pipes", "Astral Pipes", "Cera Sanitaryware", "Kajaria Ceramics",
    "Asian Paints Industrial", "Berger Paints", "Greaves Cotton Engines", "Escorts Kubota",
    "Action Construction Equipment", "Ashoka Buildcon Suppliers", "Sika India Chemicals",
    "Pidilite Construction Chemicals", "Fenner Conveyor Belts", "SKF Bearings India",
    "Bosch Rexroth Hydraulics", "Cummins Generators India",
]

pos = []
for i, v in enumerate(vendors, start=1):
    po_number = f"PO-2026-{1000+i}"
    amount = round(random.uniform(50000, 4500000), 2)
    desc = random.choice([
        "Cement bulk supply", "TMT steel bars", "Electrical cabling", "Pipe fittings",
        "Equipment rental - excavator", "Generator maintenance contract", "Paint & coating supply",
        "Elevator installation", "Motor & drive units", "Construction chemicals",
        "Conveyor belt replacement", "Bearing supply", "Hydraulic components", "Sanitaryware fixtures",
    ])
    pos.append((po_number, v, amount, desc))

# ---- Build 200 invoices ----
invoices = []
inv_counter = 5000

def new_invnum():
    global inv_counter
    inv_counter += 1
    return f"INV-{inv_counter}"

# 150 clean auto-approved matches (drawn across POs, some POs invoiced multiple times - partial deliveries)
for _ in range(150):
    po = random.choice(pos)
    invoices.append((new_invnum(), po[1], po[2], po[0], "clean"))

# 20 mismatches - amount differs meaningfully from PO
for _ in range(20):
    po = random.choice(pos)
    delta = random.choice([-1, 1]) * round(random.uniform(500, 25000), 2)
    invoices.append((new_invnum(), po[1], round(po[2] + delta, 2), po[0], "mismatch"))

# 15 duplicates - reuse an invoice number+vendor already inserted among the clean set
clean_ones = [x for x in invoices if x[4] == "clean"]
for _ in range(15):
    dup = random.choice(clean_ones)
    invoices.append((dup[0], dup[1], dup[2], dup[3], "duplicate_planted"))

# 15 no-PO - invoice references a PO number that doesn't exist
for _ in range(15):
    po = random.choice(pos)
    fake_po = f"PO-2026-{9000+random.randint(1,999)}"
    invoices.append((new_invnum(), po[1], round(random.uniform(50000, 2000000), 2), fake_po, "no_po_planted"))

random.shuffle(invoices)

with open("/home/claude/seed.sql", "w") as f:
    f.write("-- Purchase Orders\n")
    f.write("insert into purchase_orders (po_number, vendor_name, amount, description) values\n")
    f.write(",\n".join(
        f"('{p[0]}', '{p[1].replace(chr(39),chr(39)+chr(39))}', {p[2]}, '{p[3]}')" for p in pos
    ))
    f.write(";\n\n")

    f.write("-- Invoices (200, inserted in random order; trigger classifies each on insert)\n")
    f.write("insert into invoices (invoice_number, vendor_name, amount, po_reference) values\n")
    f.write(",\n".join(
        f"('{inv[0]}', '{inv[1].replace(chr(39),chr(39)+chr(39))}', {inv[2]}, '{inv[3]}')" for inv in invoices
    ))
    f.write(";\n")

print(f"Generated {len(pos)} POs and {len(invoices)} invoices")
print("Planted: 150 clean, 20 mismatch, 15 duplicate, 15 no-PO")
