-- ============================================================================
-- Seed data used for the 200-invoice proof-of-concept test
-- (40 realistic construction/infra vendor POs)
-- ============================================================================
-- Run this after schema.sql if you want to reproduce the test results
-- documented in the README (100% catch rate on planted duplicates/mismatches/
-- unauthorized spend).

insert into purchase_orders (po_number, vendor_name, amount, description) values
('PO-2026-1001', 'Tata Steel Ltd', 2895449.25, 'Cement bulk supply'),
('PO-2026-1002', 'JSW Steel', 3349899.72, 'Pipe fittings'),
('PO-2026-1003', 'Ultratech Cement', 1043287.78, 'Bearing supply'),
('PO-2026-1004', 'Ambuja Cements', 506103.53, 'Bearing supply'),
('PO-2026-1005', 'ACC Limited', 4020199.08, 'TMT steel bars'),
('PO-2026-1006', 'Shree Cement Ltd', 2677691.68, 'Cement bulk supply'),
('PO-2026-1007', 'JK Cement', 182597.63, 'Pipe fittings'),
('PO-2026-1008', 'Dalmia Bharat', 1085340.98, 'Construction chemicals'),
('PO-2026-1009', 'Larsen & Toubro Equipment', 168085.07, 'Pipe fittings'),
('PO-2026-1010', 'BharatBenz Trucks', 3236287.28, 'Bearing supply'),
('PO-2026-1011', 'Voltas Elevators', 2474989.59, 'Pipe fittings'),
('PO-2026-1012', 'Havells Electricals', 2048980.26, 'Equipment rental - excavator'),
('PO-2026-1013', 'Finolex Cables', 3651965.53, 'Cement bulk supply'),
('PO-2026-1014', 'Kirloskar Pumps', 3426692.78, 'Electrical cabling'),
('PO-2026-1015', 'Godrej Construction Supplies', 3156720.31, 'Generator maintenance contract'),
('PO-2026-1016', 'Schindler Elevators India', 1286527.47, 'Pipe fittings'),
('PO-2026-1017', 'Siemens Electricals', 4309598.17, 'Generator maintenance contract'),
('PO-2026-1018', 'ABB Motors & Drives', 504835.73, 'Paint & coating supply'),
('PO-2026-1019', 'Grasim Industries', 480387.88, 'Sanitaryware fixtures'),
('PO-2026-1020', 'Birla Corp', 1580602.97, 'Equipment rental - excavator'),
('PO-2026-1021', 'Jindal Steel & Power', 3641720.82, 'Bearing supply'),
('PO-2026-1022', 'Hindalco Industries', 2094440.71, 'TMT steel bars'),
('PO-2026-1023', 'Polycab Wires', 4380365.15, 'Paint & coating supply'),
('PO-2026-1024', 'RR Kabel', 400660.88, 'Equipment rental - excavator'),
('PO-2026-1025', 'Supreme Industries Pipes', 3740850.76, 'Construction chemicals'),
('PO-2026-1026', 'Astral Pipes', 3990260.28, 'Generator maintenance contract'),
('PO-2026-1027', 'Cera Sanitaryware', 2619217.05, 'Bearing supply'),
('PO-2026-1028', 'Kajaria Ceramics', 359520.41, 'Conveyor belt replacement'),
('PO-2026-1029', 'Asian Paints Industrial', 1064147.33, 'Equipment rental - excavator'),
('PO-2026-1030', 'Berger Paints', 4434235.77, 'Sanitaryware fixtures'),
('PO-2026-1031', 'Greaves Cotton Engines', 1085919.44, 'TMT steel bars'),
('PO-2026-1032', 'Escorts Kubota', 1741561.70, 'Elevator installation'),
('PO-2026-1033', 'Action Construction Equipment', 2878795.78, 'Generator maintenance contract'),
('PO-2026-1034', 'Ashoka Buildcon Suppliers', 773810.73, 'Generator maintenance contract'),
('PO-2026-1035', 'Sika India Chemicals', 982306.29, 'Equipment rental - excavator'),
('PO-2026-1036', 'Pidilite Construction Chemicals', 3173100.39, 'Conveyor belt replacement'),
('PO-2026-1037', 'Fenner Conveyor Belts', 2933757.46, 'Construction chemicals'),
('PO-2026-1038', 'SKF Bearings India', 2875653.38, 'Motor & drive units'),
('PO-2026-1039', 'Bosch Rexroth Hydraulics', 3294614.25, 'Electrical cabling'),
('PO-2026-1040', 'Cummins Generators India', 2107057.94, 'Equipment rental - excavator');

-- See docs/generate_test_invoices.py for the script that generated 200 test
-- invoices against these POs (150 clean matches, 20 mismatches, 15 duplicates,
-- 15 with no matching PO).
