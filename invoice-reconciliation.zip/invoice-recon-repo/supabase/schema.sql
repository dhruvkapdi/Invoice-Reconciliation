-- ============================================================================
-- Invoice Reconciliation System — Full Supabase Schema
-- ============================================================================
-- Run these in order. Designed for Postgres (Supabase).

-- ----------------------------------------------------------------------------
-- Core tables
-- ----------------------------------------------------------------------------

create table vendors (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  email text,
  created_at timestamptz not null default now()
);

-- Purchase Orders: the "source of truth" invoices are matched against.
-- In production, this is populated by procurement when a purchase is approved.
create table purchase_orders (
  id uuid primary key default gen_random_uuid(),
  po_number text not null unique,
  vendor_name text not null,
  amount numeric(14,2) not null,
  currency text not null default 'INR',
  description text,
  issued_date date not null default current_date,
  status text not null default 'open' check (status in ('open','closed','cancelled')),
  created_at timestamptz not null default now()
);

-- Invoices: raw extracted data from incoming vendor invoice emails.
create table invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_number text not null,
  vendor_name text not null,
  amount numeric(14,2) not null,
  currency text not null default 'INR',
  po_reference text,
  received_date timestamptz not null default now(),
  source text not null default 'gmail',
  source_message_id text,
  raw_extraction jsonb,
  match_status text not null default 'pending' check (
    match_status in ('pending','auto_approved','mismatch','duplicate','no_po')
  ),
  match_reason text,
  matched_po_id uuid references purchase_orders(id),
  created_at timestamptz not null default now()
);

-- Prevents true duplicate invoice numbers (per vendor) from being reprocessed.
create unique index invoices_vendor_invoice_number_first_seen
  on invoices (vendor_name, invoice_number)
  where match_status <> 'duplicate';

-- Payment queue: the final "approved for payment" feed.
create table payment_queue (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid not null references invoices(id),
  status text not null default 'pending_review' check (
    status in ('approved','flagged','blocked','pending_review')
  ),
  amount numeric(14,2) not null,
  notes text,
  created_at timestamptz not null default now()
);

create index idx_invoices_match_status on invoices(match_status);
create index idx_invoices_created_at on invoices(created_at);
create index idx_po_number on purchase_orders(po_number);

-- ----------------------------------------------------------------------------
-- Matching engine — runs automatically on every invoice insert
-- ----------------------------------------------------------------------------
-- This is the heart of the system. It is a database trigger, not an n8n
-- workflow, so it fires instantly and atomically the moment a row lands in
-- `invoices` — no polling delay, and it works regardless of which system
-- (n8n, a script, a future integration) writes the row.

create or replace function match_invoice() returns trigger as $$
declare
  po purchase_orders%rowtype;
  dup_count int;
  amt_diff numeric(14,2);
  tolerance numeric(14,2) := 1.00; -- allow up to ₹1 rounding difference
begin
  -- 1. Duplicate check: same vendor + invoice number already processed?
  select count(*) into dup_count
  from invoices
  where vendor_name = NEW.vendor_name
    and invoice_number = NEW.invoice_number
    and id <> NEW.id
    and match_status <> 'duplicate';

  if dup_count > 0 then
    NEW.match_status := 'duplicate';
    NEW.match_reason := 'Invoice number ' || NEW.invoice_number || ' for vendor ' || NEW.vendor_name || ' was already processed.';
    return NEW;
  end if;

  -- 2. Find matching PO by po_reference
  select * into po from purchase_orders
  where po_number = NEW.po_reference
  limit 1;

  if not found then
    NEW.match_status := 'no_po';
    NEW.match_reason := 'No purchase order found matching reference "' || coalesce(NEW.po_reference, '(none provided)') || '".';
    return NEW;
  end if;

  -- 3. Amount check
  amt_diff := abs(NEW.amount - po.amount);
  if amt_diff <= tolerance then
    NEW.match_status := 'auto_approved';
    NEW.match_reason := 'Matched PO ' || po.po_number || ', amount matches within tolerance.';
    NEW.matched_po_id := po.id;
  else
    NEW.match_status := 'mismatch';
    NEW.match_reason := 'Matched PO ' || po.po_number || ' but amount differs by ' || amt_diff || ' ' || NEW.currency || ' (invoice: ' || NEW.amount || ', PO: ' || po.amount || ').';
    NEW.matched_po_id := po.id;
  end if;

  return NEW;
end;
$$ language plpgsql
set search_path = public, pg_temp;

create trigger trg_match_invoice
before insert on invoices
for each row execute function match_invoice();

-- After match_status is set, route the invoice into the payment queue.
create or replace function route_to_payment_queue() returns trigger as $$
begin
  insert into payment_queue (invoice_id, status, amount, notes)
  values (
    NEW.id,
    case NEW.match_status
      when 'auto_approved' then 'approved'
      when 'mismatch' then 'flagged'
      when 'duplicate' then 'blocked'
      when 'no_po' then 'flagged'
      else 'pending_review'
    end,
    NEW.amount,
    NEW.match_reason
  );
  return NEW;
end;
$$ language plpgsql
set search_path = public, pg_temp;

create trigger trg_route_to_payment_queue
after insert on invoices
for each row execute function route_to_payment_queue();

-- ----------------------------------------------------------------------------
-- Digest views — power the daily Slack summary without needing raw DB creds
-- ----------------------------------------------------------------------------

create view v_recent_digest_summary as
select
  match_status,
  count(*) as invoice_count,
  sum(amount) as total_amount
from invoices
where created_at > now() - interval '1 day'
group by match_status;

create view v_recent_flagged_invoices as
select
  invoice_number,
  vendor_name,
  amount,
  currency,
  po_reference,
  match_status,
  match_reason,
  created_at
from invoices
where created_at > now() - interval '1 day'
  and match_status <> 'auto_approved'
order by created_at desc;

alter view v_recent_digest_summary set (security_invoker = true);
alter view v_recent_flagged_invoices set (security_invoker = true);

-- ----------------------------------------------------------------------------
-- Observability + self-healing: pipeline_runs log and circuit breaker
-- ----------------------------------------------------------------------------

create table pipeline_runs (
  id uuid primary key default gen_random_uuid(),
  workflow_name text not null,
  status text not null check (status in ('success','failure')),
  error_detail text,
  run_at timestamptz not null default now()
);

create index idx_pipeline_runs_workflow_time on pipeline_runs(workflow_name, run_at desc);

-- Counts consecutive failures per workflow (walks backward from the most
-- recent run until it hits a success). Used by the circuit breaker to decide
-- when to trip.
create view v_consecutive_failures as
with ranked as (
  select
    workflow_name,
    status,
    error_detail,
    run_at,
    row_number() over (partition by workflow_name order by run_at desc) as rn
  from pipeline_runs
),
first_success as (
  select workflow_name, min(rn) as first_success_rn
  from ranked
  where status = 'success'
  group by workflow_name
)
select
  r.workflow_name,
  count(*) filter (where r.status = 'failure') as consecutive_failures,
  max(r.run_at) filter (where r.status = 'failure') as last_failure_at,
  (array_agg(r.error_detail order by r.run_at desc) filter (where r.status = 'failure'))[1] as last_error_detail
from ranked r
left join first_success fs on fs.workflow_name = r.workflow_name
where r.status = 'failure'
  and (fs.first_success_rn is null or r.rn < fs.first_success_rn)
group by r.workflow_name;

alter view v_consecutive_failures set (security_invoker = true);

-- Kill switch: the ingestion workflow checks this before doing any work.
-- The circuit breaker flips it off after 3+ consecutive failures.
-- (Chosen over n8n's REST API for deactivation, since API access is often
-- restricted on trial/free n8n plans — this works on any plan.)
create table pipeline_config (
  id smallint primary key default 1 check (id = 1),
  ingestion_enabled boolean not null default true,
  disabled_reason text,
  updated_at timestamptz not null default now()
);

insert into pipeline_config (id, ingestion_enabled) values (1, true);

-- ----------------------------------------------------------------------------
-- Row Level Security
-- ----------------------------------------------------------------------------
-- n8n connects with the service_role key (bypasses RLS by design), so these
-- tables are locked down against the anon/publishable key by default.

alter table vendors enable row level security;
alter table purchase_orders enable row level security;
alter table invoices enable row level security;
alter table payment_queue enable row level security;
alter table pipeline_runs enable row level security;
alter table pipeline_config enable row level security;
